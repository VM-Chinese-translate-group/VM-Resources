![爬行者酶腺](item:betterwithmods:creeper_oyster)

爬行者酶腺是爬行者至关重要的外部器官，是爬行者自身爆炸的来源。A Creeper Oyster is a vital external organ of a Creeper that appears to be the source of their ability to explode at will. 
Due to their external exposure, one can probably cut them off with shears. 

Since these oysters have the ability to explode, it could be useful for the melding of materials, such as [Diamond Ingots](diamond_ingot.md)
